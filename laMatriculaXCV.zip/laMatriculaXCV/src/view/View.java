package view;


import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;



public class View {

	/*
	 * We declare this as public so we can get it from other packages
	 */
	public JFrame frame;
	public static JButton btnAfegeix;
	public static JButton btnReinicia;
	public static JComboBox cbAssignatures;
	public static JComboBox<String> cbCurs;
	public static JTextArea taAssignatures;
	public static JTextArea taPreuCredit;
	public static JLabel lblPreuTotal;
	/**
	 * Create the application.
	 */
	public View() {
		initialize();
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {


		frame = new JFrame();
		frame.setTitle("La Matrícula");
		frame.setResizable(false);
		frame.setBounds(100, 100, 627, 521);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		/*
		 * Panels
		 */
		JPanel panelMenu = new JPanel();
		panelMenu.setBorder(new TitledBorder(null, "La Matricula", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelMenu.setBounds(0, 0, 612, 488);
		frame.getContentPane().add(panelMenu);
		panelMenu.setLayout(null);

		JPanel panelPrice = new JPanel();
		panelPrice.setBounds(10, 422, 592, 54);
		panelMenu.add(panelPrice);
		panelPrice.setBackground(new Color(128, 255, 128));
		panelPrice.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "PREU", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(306, 318, 285, 93);
		panelMenu.add(panel);
		panel.setLayout(null);

		JLabel lblPreu = new JLabel("Preu / credit (€)");
		lblPreu.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblPreu.setBounds(20, 23, 127, 18);
		panel.add(lblPreu);



		/*
		 * Local labels
		 */
		lblPreuTotal = new JLabel("Preu Total = 0.0 €");
		lblPreuTotal.setBounds(10, 11, 572, 37);
		lblPreuTotal.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblPreuTotal.setHorizontalAlignment(0);
		panelPrice.add(lblPreuTotal);


		JLabel lblFoto = new JLabel("");
		lblFoto.setIcon(new ImageIcon(View.class.getResource("/view/logo.png")));
		lblFoto.setBounds(405, 22, 139, 108);
		panelMenu.add(lblFoto);

		JLabel lblCurs = new JLabel("Curs");
		lblCurs.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblCurs.setBounds(326, 143, 46, 14);
		panelMenu.add(lblCurs);


		JLabel lblAssignaturesTitol = new JLabel("Assignatures");
		lblAssignaturesTitol.setFont(new Font("Courier New", Font.BOLD, 16));
		lblAssignaturesTitol.setBounds(10, 11, 238, 25);
		panelMenu.add(lblAssignaturesTitol);

		JLabel lblAssignatures = new JLabel("Assignatures");
		lblAssignatures.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblAssignatures.setBounds(296, 208, 295, 22);
		lblAssignatures.setHorizontalAlignment(0);
		panelMenu.add(lblAssignatures);


		/*
		 * TextArea Assignatures
		 */
		taAssignatures = new JTextArea();
		taAssignatures.setSelectionColor(new Color(128, 255, 128));
		taAssignatures.setEditable(false);
		taAssignatures.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		taAssignatures.setBounds(10, 32, 276, 379);
		panelMenu.add(taAssignatures);

		/*
		 * ComboBox Curs
		 */
		cbCurs = new JComboBox<String>();
		cbCurs.setBounds(382, 141, 209, 22);

		//We need to initialize it first
		model.CursIAssignatures.cursos();
		for(String icurs : model.CursIAssignatures.cursos) {
			cbCurs.addItem(icurs);
		}
		panelMenu.add(cbCurs);

		/*
		 * ComboBox Assignatures
		 */
		cbAssignatures = new JComboBox();
		cbAssignatures.setBounds(306, 241, 285, 22);
		panelMenu.add(cbAssignatures);



		/*
		 * Button Afegeix
		 */
		btnAfegeix = new JButton("Afegeix");
		btnAfegeix.setForeground(new Color(0, 0, 0));
		btnAfegeix.setBounds(340, 274, 89, 23);
		panelMenu.add(btnAfegeix);



		/*
		 * Button Reinicia
		 */
		btnReinicia = new JButton("Reinicia");
		btnReinicia.setBounds(462, 274, 89, 23);
		panelMenu.add(btnReinicia);



		/*
		 *TextArea PreuCredit 
		 */
		taPreuCredit = new JTextArea();
		taPreuCredit.setFont(new Font("Monospaced", Font.PLAIN, 16));
		taPreuCredit.setSelectionColor(new Color(128, 255, 128));
		taPreuCredit.setText("100");
		taPreuCredit.setBounds(160, 19, 87, 26);
		panel.add(taPreuCredit);

	}
}
