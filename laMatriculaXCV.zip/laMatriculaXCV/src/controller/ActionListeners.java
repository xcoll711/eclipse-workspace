package controller;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.rmi.AccessException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.border.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import model.Functions;
import view.View;

public class ActionListeners {

	//Declarations
	private HashMap<String, Integer> assignatures = new HashMap<>();
	private ArrayList<Double> credits = new ArrayList<>();;

	
	public void buttons() {

		//This actionListeners execute when someone presses or do something with the item.
		
		
		View.btnAfegeix.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//Grabs the item from the comboBox Assignatures and insert it in the String
				String selectedItem = (String) View.cbAssignatures.getSelectedItem();
				
				
				Functions.addAssignatura(selectedItem, View.taPreuCredit, View.lblPreuTotal, credits);
				
			}
		});



		View.btnReinicia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Functions.reinicia(View.cbCurs, assignatures, credits);
			}
		});





		View.cbCurs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Functions.chooseCursAndAssignatura(View.cbCurs, assignatures);
			}
		});



		View.taPreuCredit.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                actualizarLabel();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                actualizarLabel();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
            	//We don't need this for the textarea
            }

            private void actualizarLabel() {
				Functions.updateSumCredits(credits, View.taPreuCredit, View.lblPreuTotal);

            }
            

		});
	


	}

}



