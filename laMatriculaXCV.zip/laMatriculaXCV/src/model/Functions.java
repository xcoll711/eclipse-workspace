package model;

import javax.swing.*;
import java.util.*;

import view.View;


public class Functions {

	public static void addAssignatura(String selectedItem, JTextArea taPreuCredit, JLabel lblPreuTotal, ArrayList<Double> credits) {
		try {
			if (!View.taAssignatures.getText().contains(selectedItem) && selectedItem != null && !selectedItem.trim().isEmpty()) {
				View.taAssignatures.append(selectedItem + "\n");

				// Obtains the number of credits if available
				String creditString = selectedItem.substring(selectedItem.indexOf(":") + 2).trim();

				// Check if creditString is not null or empty before parsing it
				if (!creditString.isEmpty()) {
					try {
						double credit = Double.parseDouble(creditString);
						credits.add(credit);

						// Update the sum of credits using the method
						updateSumCredits(credits, taPreuCredit, lblPreuTotal);

					} catch (NumberFormatException ex) {
						System.err.println("Invalid credit value: " + creditString + " is not a number.");
					}
				} else {
					System.err.println("-- Credit value is empty.");
				}
			} else {
				System.err.println("-- Selected item is null, empty or already used.");
			}
		} catch (NullPointerException ex) {
			System.err.println("-- Selected item is empty.");
		} catch (Exception ex) {
			System.err.println(ex.getMessage());
		}
	}


	public static void reinicia(JComboBox<String> cbCurs, HashMap<String, Integer> assignatures, ArrayList<Double> credits) {
		try {
			// We put everything to its default values
			cbCurs.setSelectedIndex(0);
			View.cbAssignatures.removeAllItems();
			assignatures.clear();
			credits.clear();
			View.lblPreuTotal.setText("Preu Total = 0.00 €");
			View.taAssignatures.setText(null);

		} catch (Exception ex) {
			System.err.println(ex.getMessage());
		}
	}

	public static void chooseCursAndAssignatura(JComboBox<String> cbCurs,  HashMap<String, Integer> assignatures) {
		try {
			int i = 0;

			//Restart everything before putting all the new assignatures
			View.cbAssignatures.removeAllItems();
			assignatures.clear();

			//Gets the selected Assignatura and puts all the assignatures inside it
			int selected = cbCurs.getSelectedIndex();
			switch (selected) {
			case 1 -> assignatures.putAll(CursIAssignatures.aSMX1);
			case 2 -> assignatures.putAll(CursIAssignatures.aSMX2);
			case 3 -> assignatures.putAll(CursIAssignatures.aDAW1);
			case 4 -> assignatures.putAll(CursIAssignatures.aDAW2);
			case 5 -> assignatures.putAll(CursIAssignatures.aDAM1);
			case 6 -> assignatures.putAll(CursIAssignatures.aDAM2);
			}

			//Insert each assignatura one by one
			for (String icurs : assignatures.keySet()) {
				View.cbAssignatures.addItem(icurs + " - Credits: " + assignatures.get(icurs) + " ");
				i++;
			}

			// The best handle for null pointer exception it's ignoring it
		} catch (NullPointerException ex) {

			//General Exception catch
		} catch (Exception ex) {
			System.err.println(ex.getMessage());
		}
	}


	public static void updateSumCredits(ArrayList<Double> credits, JTextArea taPreuCredit, JLabel lblPreuTotal) {
		
		double sumCredits = 0;
		
		for (Double c : credits) {
			sumCredits += c;
		}

		
		try {
			
			double preuCredits = Double.parseDouble(taPreuCredit.getText());
			
			// If preuCredit is 0 it will write a 0 as default
			lblPreuTotal.setText("Preu Total = "+ String.valueOf(sumCredits * preuCredits>0?preuCredits*sumCredits:0)+ " €");
		} catch (NumberFormatException ex) {
			lblPreuTotal.setText("Preu Total = 0.0 €");
			System.out.println("Invalid preuCredit value: " + taPreuCredit.getText());
		}
	}
}
