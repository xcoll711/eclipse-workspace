
nombre = input("Por favor, introduce tu nombre: ")

longitud_nombre = len(nombre)

print("Hola, " + nombre + ". Tu nombre tiene " + str(longitud_nombre) + " letras.")
