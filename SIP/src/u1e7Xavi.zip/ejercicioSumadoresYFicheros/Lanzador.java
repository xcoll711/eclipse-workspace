/*Crear un programa que permita parametrizar el lanzamiento de sumadores,
que vuelque el contenido de las sumas en ficheros y que permita al
programa principal recuperar las sumas de los ficheros parciales.*/


/*iNCLUYE 1.7*/




package ejercicioSumadoresYFicheros;

import java.io.*;

public class Lanzador {

	public static void main(String[] args) throws IOException {

		//RUTA RELATIVA DEL SUMADOR
		ProcessBuilder pb = new ProcessBuilder("java","src/ejercicioSumadoresYFicheros/Sumador2.java");



		//afegit 1.7 --> es necessita un fitxer de text anomenat entrada.txt amb 2 nombres 
		File fIn = new File ("entrada.txt");

		//ESCRIBIRÁ AQUI
		File fOut = new File ("salida.txt");
		File fErr = new File ("error.txt");

		//afegit 1.7
		pb.redirectInput(fIn);

		pb.redirectOutput(ProcessBuilder.Redirect.appendTo(fOut));
		pb.redirectError(fErr);


		Process p = pb.start();

		/*//escritura 
		OutputStream os = p.getOutputStream();
		os.write("50\n".getBytes());
		os.write("37\n".getBytes());
		os.flush();*/


		//COMPROBACIÓN ERROR -> 0 BIEN, 1 MAL
		int exitVal;
		try {
			exitVal = p.waitFor();
			System.out.println("Valor salida: "+ exitVal);
		}catch(InterruptedException e) {
			System.out.println(e.getMessage());
		}

	}

}
