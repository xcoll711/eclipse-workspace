package u2e1;

public class Tac extends Thread {

    @Override
    public void run() {
        while (true) {
            try {
                System.out.println("TAC");
                Thread.sleep(777);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}